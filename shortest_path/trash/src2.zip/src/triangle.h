#ifndef __TRINAGLES_H_INCLUDED__
#define __TRINAGLES_H_INCLUDED__

#define MAXTRIANGLES 1001

typedef struct {
	int x;				/* x position */
	int y;				/* y position */
} point;

typedef struct {
	point points[3];
} triangle;

typedef struct {
	triangle triangles[MAXTRIANGLES];
	int numTriangles;
} triangleList;

void read_triangles(triangleList *triangleList, const char *filename);

#endif __TRINAGLES_H_INCLUDED__