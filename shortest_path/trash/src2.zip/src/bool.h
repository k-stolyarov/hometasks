#ifndef __BOOL_H_INC__
#define __BOOL_H_INC__

#define TRUE    1
#define FALSE   0

typedef int bool;

#endif // __BOOL_H_INC__